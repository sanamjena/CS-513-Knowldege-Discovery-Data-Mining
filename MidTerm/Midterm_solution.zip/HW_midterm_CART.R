





#Load the CANVAS "COVID19_v3.CSV" dataset into R/Python.
#Remove the missing values. 

#Construct a CART model to classify infection ("infected') based on the other variables.
#Measure the accuracy of the model.

rm(list=ls())
dev.off()
file<-file.choose()

Covid_raw<-  read.csv(file)
summary(Covid_raw)

Covid_nomissing<-na.omit(Covid_raw)
#Discretize the "MonthAtHospital" into "less than 6 months"and "6 or more months".
MH_cat<- ifelse(Covid_nomissing$MonthAtHospital<6,"<6",">=6") 
#Also discretize the age into "less than 35", "35 to 50" and "51 or over".
age_cat<- ifelse(Covid_nomissing$Age<35,"L35",ifelse(Covid_nomissing$Age>50,"M50","B35_50")) 

#ID	Age	Exposure	MaritalStatus	Cases	MonthAtHospital	Infected

Covid_clean<-data.frame(
                  cbind(age_cat=factor(age_cat)
                  ,Exposure=factor(Covid_nomissing$Exposure)
                  ,MaritalStatus=factor(Covid_nomissing$MaritalStatus)
                  ,Cases=Covid_nomissing$Cases
                  ,MH_cat=factor(MH_cat)
                  ,Infected= factor(Covid_nomissing$Infected)  
                  )
               )
index<-sort(sample(nrow( Covid_clean),round(.30*nrow(Covid_clean  ))))
training<- Covid_clean[-index,]
test<- Covid_clean[index,]

library(rpart)
library(rpart.plot)  			# Enhanced tree plots
library(rattle)           # Fancy tree plot
library(RColorBrewer)     # colors needed for rattle 

CART_class<-rpart( factor(Infected) ~.,data=training )
rpart.plot(CART_class)
dev.off()
CART_predict<-predict(CART_class,test,,type="class")
df<-as.data.frame(cbind(test,CART_predict))
 
table(Actual=test[,"Infected"],CART=CART_predict)

CART_wrong<-sum(test[,"Infected"]!=CART_predict)

error_rate=CART_wrong/length(test$Infected )                      
