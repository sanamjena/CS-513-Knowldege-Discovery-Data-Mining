#################################################
#  Company    : Stevens 
#  Project    : R Bootcamp 
#  Purpose    : Function
#  First Name  : Khasha
#  Last Name  : Dehnad
#  Id			    :  
#  Date       :
#  Comments   : Midterm EDA problem

rm(list=ls())
#################################################
##   Step:
## 
##
######################

rm(list=ls())



#Load the "Adult_income_EDA.csv" and perform the following exploratory data analysis:
file<-file.choose()
EDA<-  read.csv(file,na.strings = " ?")

is.na(EDA)
colSums(is.na(EDA))

#	Find maximum, minimum, median, mean and the standard deviation of the numeric features
summary(EDA)

#III.	Displaying the frequency table of "Infected" vs. "MaritalStatus" 
table(EDA$Infected,EDA$MaritalStatus)

#IV.	Displaying the scatter plot of "Age", "Infected" and "MonthAtHospital", one pair at a time
pairs(EDA[,c(2,6,7)]) 
cols<-c('Age','Infected', 'MonthAtHospital')
pairs(EDA[,c('Age','Infected', 'MonthAtHospital') ])
dev.off()
#V.	Show box plots for columns:  "Age", "MaritalStatus" and "MonthAtHospital"
boxplot(EDA[,c(2,4,6)])


#	Replace the missing value with the median of the numbers

#No Missing values to be replaced.



