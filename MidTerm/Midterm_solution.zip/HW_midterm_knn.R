

#Load the CANVAS fictional "COVID19_v3.CSV"dataset into R/Python.
#Remove the missing values.
#Use unweighted knn(k=5) to  predict infection rate (infected)
#for a random sample (30%) of the data (test dataset).
#################################################
##   Step:
## 
##
######################
 
rm(list=ls())
dev.off()
file<-file.choose()

Covid_raw<-  read.csv(file)
summary(Covid_raw)

Covid_noNA<-na.omit(Covid_raw)

mmnorm2 <-function(x)
{z<-((x-min(x))/(max(x)-min(x)))
return(z)                              
}
myvector<-1:20
mmnorm2(myvector)


#ID	Age	Exposure	MaritalStatus	Cases	MonthAtHospital	Infected
is.factor(Covid_noNA$Infected)

## normalizing the data before creating test and training
Covid<-data.frame(Age=mmnorm2(Covid_noNA$Age )
                 , Exposure=mmnorm2(Covid_noNA$Exposure )
                 , MaritalStatus1=ifelse(Covid_noNA$MaritalStatus=="Married",1,0)
                 , MaritalStatus2=ifelse(Covid_noNA$MaritalStatus=="Divorced",1,0)
                 , Cases=mmnorm2(Covid_noNA$Cases )
                 , MonthAtHospital= mmnorm2(Covid_noNA$MonthAtHospital )
                 , Infected=Covid_noNA$Infected 
)

#b. and c.	create training and test data sets 
index<-sort(sample(nrow(Covid),round(.30*nrow(Covid))))
training<-  Covid[-index,]
test<-  Covid[index,]

 

library(kknn) 
predict_k5 <- kknn(formula= Infected~., training[] , test[], k=5,kernel ="rectangular"  )

fit <- fitted(predict_k5)
table(test$Infected ,fit)



#e.	Measure the performance of knn

wrong<- ( test$Infected !=fit)
rate<-sum(wrong)/length(wrong)
rate

