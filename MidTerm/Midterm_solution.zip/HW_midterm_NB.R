



rm(list=ls())
dev.off()
file<-file.choose()

Covid_raw<-  read.csv(file)
summary(Covid_raw)

Covid_nomissing<-na.omit(Covid_raw)
#Discretize the "MonthAtHospital" into "less than 6 months"and "6 or more months".
MH_cat<- ifelse(Covid_nomissing$MonthAtHospital<6,"<6",">=6") 
#Also discretize the age into "less than 35", "35 to 50" and "51 or over".
age_cat<- ifelse(Covid_nomissing$Age<35,"L35",ifelse(Covid_nomissing$Age>50,"M50","B35_50")) 

#ID	Age	Exposure	MaritalStatus	Cases	MonthAtHospital	Infected

Covid_clean<-data.frame(
  cbind(age_cat=factor(age_cat)
        ,Exposure=factor(Covid_nomissing$Exposure)
        ,MaritalStatus=factor(Covid_nomissing$MaritalStatus)
        ,Cases=Covid_nomissing$Cases
        ,MH_cat=factor(MH_cat)
        ,Infected= factor(Covid_nomissing$Infected)  
  )
)
index<-sort(sample(nrow( Covid_clean),round(.30*nrow(Covid_clean  ))))
training<- Covid_clean[-index,]
test<- Covid_clean[index,]


library(e1071)
nBayes <- naiveBayes( factor(Infected)~., data =training )

## Naive Bayes classification using all variables 

category_all<-predict(nBayes,test  )


table(NBayes=category_all,Survived=test$Infected )
NB_wrong<-sum(category_all!=test$Infected   )
NB_error_rate<-NB_wrong/length(category_all)
NB_error_rate

